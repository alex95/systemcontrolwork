//Rfid 5.0
#define PIN_SPK 5 //pin спикера
#define SS_PIN 16  //pin ss rfid
#define RST_PIN 5 //pin rst rfid
#define NUM_LEDS 8  //кол-во светодиодов
#define PIN_LEDS 15 //pin 1-го светодиода

#include <Arduino.h>
#include <Ticker.h> 
#include <SPI.h>
#include <MFRC522.h>
#include "FastLED.h"
#include <ESP8266WiFi.h>
#include <ESP8266Ping.h>
#include <PubSubClient.h>

void rcread();
void color_rainboow();
void color_rfid();
void color_blue();
void color_red();
void color_yellow();
void senddata();

Ticker reboottimer;
MFRC522 mfrc522(SS_PIN, RST_PIN);
CRGB leds[NUM_LEDS]; //последовательность RGB
WiFiClient espClient;
PubSubClient client(espClient);

int out = 0;
int stread = 0;
int streads = 0;
int blocktime2;
float counter;
float counters;
int rbsr;
String rcuid = "";
String rcuids = "";

int setbrg = 250;        //яркость радуги
int setbrg1 = 250 ;        //яркость сплошных цветов цвет
int rbn_time1 = 850 ;     //задержка цвет
int rbn_time2 = 250 ;      //задержка черный
int rbnshag = 5 ;        //шаг радуги
int rbnspeed = 80 ;      //скорость радуги
int blocktime = 12;      //блокировка время повторного считывания
int spkMHz = 2500;         //частота спикера
int spk_beeptime = 130;  //время спикера
int typycode = 0;         //тип кода 522 0-hex_lite  1-DEC 2-HEX
float rebootesp = 86400.0; //время reboot, sec
const char* ssid = "CRB_priemnoe"; //wifi SSID
const char* password = "alex1377"; //wifi Password
const char* mqttServer = "192.168.0.67"; 
const int mqttPort = 1883;
const char* mqttUser = "crb"; 
const char* mqttPassword = "crb";
const char* msgTopic = "crb/uid";
const char* msgconect = "CRB priemnoe 240";
const IPAddress hostName(192, 168, 0, 67); //ip mqtt для пинга
int pingResult = 1;
IPAddress ipadress(192,168,0,240);
IPAddress gatewayadress(192,168,0,200);
IPAddress subnetadress(255,255,255,0);

void restart(){
ESP.restart();
} 

void setup() {
  //Serial.begin(115200);
  SPI.begin();      
  mfrc522.PCD_Init();   
  FastLED.addLeds<WS2811, PIN_LEDS, GRB>(leds, NUM_LEDS).setCorrection( TypicalLEDStrip );
  WiFi.config(ipadress, gatewayadress, subnetadress);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) 
  {
     delay(500);
     color_blue();
  }
   client.setServer(mqttServer, mqttPort);
     while (!client.connected()) {
      color_yellow(); //Connecting to MQTT...
  if (client.connect("espClient", mqttUser, mqttPassword )) {
       color_rfid();  //connected
     } else {
      color_red();  //failed with state
      delay(2000);
    }
  }
  client.publish("crb", msgconect); //Restart info 
  reboottimer.attach(rebootesp, restart);
  }

void loop() {
color_rainboow(); 
senddata();
rcread();
if (WiFi.status() != WL_CONNECTED)
    {
      color_blue();
      ESP.restart();
    } 
// pingResult =  Ping.ping(hostName);    
// if (pingResult == 0) {
// ESP.restart();
// }
} 

void senddata(){
if (rcuid != rcuids){
  rcuids = rcuid;
  char msgOut [25];
  rcuid.toCharArray(msgOut,25);
  client.connect("espClient", mqttUser, mqttPassword );
  client.publish(msgTopic,msgOut);
  client.subscribe(msgTopic); 
  color_rfid();  
  }  
else if ( streads == 1){
  char msgOut [25];
  rcuid.toCharArray(msgOut,25);
  client.connect("espClient", mqttUser, mqttPassword );
  client.publish(msgTopic, msgOut);
  color_rfid();
  stread = 1;
  streads = 0;
  }
}

void rcread() {
   if ( ! mfrc522.PICC_IsNewCardPresent())   {
    return;
  }
  if ( ! mfrc522.PICC_ReadCardSerial())   {
    return;
  }
  String uid522DEC= "";
  String uid522HEX= "";
  String uid522HEXs= "";
  byte letter;
  blocktime2 = blocktime + 1;   
  for (byte i = 0; i < mfrc522.uid.size; i++) 
  {
     uid522DEC.concat(String(mfrc522.uid.uidByte[i] < 0x10 ? "0" : ""));
     uid522DEC.concat(String(mfrc522.uid.uidByte[i], DEC));
     uid522HEX.concat(String(mfrc522.uid.uidByte[i] < 0x10 ? "0" : ""));
     uid522HEX.concat(String(mfrc522.uid.uidByte[i], HEX));
     uid522HEXs.concat(String(mfrc522.uid.uidByte[i] < 0x10 ? "0" : ""));
     uid522HEXs.concat(String(mfrc522.uid.uidByte[i], HEX));
  }
     uid522HEXs.toUpperCase();

    
  if (uid522HEX != rcuid && typycode == 0){
    rcuid = uid522HEX;
    stread = 1;
    tone(PIN_SPK, spkMHz, spk_beeptime);
    Serial.print(" UID tag HEX mqtt :");
    Serial.println(rcuid);
    }
    else if (uid522HEX == rcuid && typycode == 0 && stread <= blocktime){
    stread++;
    }  
    else if (uid522HEX == rcuid && typycode == 0 && stread == blocktime2){
    stread = 0;
    streads = 1;
    tone(PIN_SPK, spkMHz, spk_beeptime);
    }

    if (uid522DEC != rcuid && typycode == 1 ){
    rcuid = uid522DEC;
    tone(PIN_SPK, spkMHz, spk_beeptime);
    Serial.print(" UID tag DEC mqtt :");
    Serial.println(rcuid);
    }

    if (uid522HEXs != rcuid &&  typycode == 2){
    rcuid = uid522HEXs;
    tone(PIN_SPK, spkMHz, spk_beeptime);
    Serial.print(" UID tag HEXs mqtt :");
    Serial.println(rcuid);
    }
    }

void color_rainboow() { 
  FastLED.setBrightness(setbrg);
  for (int i = 0; i < NUM_LEDS; i++ ) { 
    leds[i] = CHSV(counter + i * rbnshag, 255, 255);  // умножение i уменьшает шаг радуги
  }
    counters = rbnspeed * 0.01;
    counter = counter + counters;        // counter меняется от 0 до 255 (тип данных byte)
  FastLED.show();
}

void color_rfid() { 
  FastLED.setBrightness(setbrg1);
  for (int i = 0; i < NUM_LEDS; i++ ) { 
    leds[i] = CRGB::Green;;  
  }
  FastLED.show();
  FastLED.delay(rbn_time1);
  for (int i = 0; i < NUM_LEDS; i++ ) { 
    leds[i] = CRGB::Black;;
  }
  FastLED.show();
}

void color_red() { 
  FastLED.setBrightness(setbrg1);
  for (int i = 0; i < NUM_LEDS; i++ ) { 
    leds[i] = CRGB::Red;;  
  }
  FastLED.show();

}

void color_blue() { 
  FastLED.setBrightness(setbrg1);
  for (int i = 0; i < NUM_LEDS; i++ ) { 
    leds[i] = CRGB::Blue;;  
  }
  FastLED.show();
  FastLED.delay(250);
  for (int i = 0; i < NUM_LEDS; i++ ) { 
    leds[i] = CRGB::Black;;
  }
  FastLED.show();
}

void color_yellow() { 
  FastLED.setBrightness(setbrg1);
  for (int i = 0; i < NUM_LEDS; i++ ) { 
    leds[i] = CRGB::Yellow;;  
  }
  FastLED.show();
}
 
